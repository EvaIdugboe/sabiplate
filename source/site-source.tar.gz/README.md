# SabiPlate

SabiPlate is a responsive static meal-planning app with Supabase email/password authentication and per-user cloud sync.

## Run locally

```bash
npm install
npm run build
python3 -m http.server 4173
```

Open `http://localhost:4173`.

## Account flow

- Guests can use the full browser app without an account.
- **Create account** and **Sign in** are available in the top navigation and Profile screen.
- Email confirmation and password recovery are handled by Supabase Auth.
- Signed-in users automatically sync SabiPlate local state to `public.user_app_state`.
- Profile and favourite data are also mirrored to normalized, row-level-secured tables.

## Build

`src/auth-sync.js` is bundled with the pinned Supabase client into `assets/auth-sync.bundle.js` using esbuild.

The restored cookbook cover is stored at `assets/sabiplate-brand-reference.jpg`. Every recipe image is packaged under `assets/recipes/`; the app no longer relies on private `sabi:` URLs or remote image hosts.

## Interaction fixes

- The exact-couple planner, shopping, prep and profile enhancements use explicit render events instead of a page-wide MutationObserver.
- The **See batch-cook quantities** action opens the real Meal prep view.
- All embedded recipe images and the hero/cookbook cover resolve without internal placeholder URLs.

## Database

Apply the SQL files in `supabase/migrations/` in timestamp order. They create the private app-state table, enable row-level security, and restrict browser database grants.

## Production

The intended live production address is <https://sabiplate.vercel.app>.
